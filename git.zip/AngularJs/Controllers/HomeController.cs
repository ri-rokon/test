﻿using AngularJs.Models;
using AngularJs.Repository;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AngularJs.Controllers
{
    public class HomeController : Controller
    {
        private readonly IRepository _repository;
        public HomeController(IRepository repository)
        {
            _repository = repository;
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public JsonResult AngularTest()
        {
            AllCoreEntities e = new AllCoreEntities();
            var obj = e.divLists.ToList();
            return Json(obj, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public ActionResult getEmployee()
        {
            List<EmployeeRecord> list = new List<EmployeeRecord>();

            list = _repository.GetEmployees();

            string json_data = JsonConvert.SerializeObject(list);

            return Json(json_data, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult AddEmployee(EmployeeRecord empdetails)
        {
            string result = _repository.AddAddEmployee(empdetails);

            List<EmployeeRecord> list = new List<EmployeeRecord>();
            list = _repository.GetEmployees();

            string json_data = JsonConvert.SerializeObject(list);

            return Json(json_data, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateEmployee(EmployeeRecord empdetails)
        {
            string result = _repository.UpdateEmployee(empdetails);

            List<EmployeeRecord> list = new List<EmployeeRecord>();
            list = _repository.GetEmployees();

            string json_data = JsonConvert.SerializeObject(list);

            return Json(json_data, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult DeleteEmployee(int ID)
        {
            string result = _repository.DeleteEmployee(ID);

            List<EmployeeRecord> list = new List<EmployeeRecord>();
            list = _repository.GetEmployees();

            string json_data = JsonConvert.SerializeObject(list);

            return Json(json_data, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult TEst(int ID)
        {
            string result = _repository.DeleteEmployee(ID);

            List<EmployeeRecord> list = new List<EmployeeRecord>();
            list = _repository.GetEmployees();

            string json_data = JsonConvert.SerializeObject(list);

            return Json(json_data, JsonRequestBehavior.AllowGet);
        }



    }
}