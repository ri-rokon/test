﻿using AngularJs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AngularJs.Repository
{
    public interface IRepository
    {
        List<EmployeeRecord> GetEmployees();
        string AddAddEmployee(EmployeeRecord empDetails);
        string UpdateEmployee(EmployeeRecord empdetails);
        string DeleteEmployee(int id);
    }
}
