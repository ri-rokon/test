﻿CREATE PROCEDURE [dbo].[DeleteEmployee] 
     @ID int 
 AS
 BEGIN
     SET NOCOUNT ON;
     Delete From EmployeeRecord  WHERE ID = @ID   
 END