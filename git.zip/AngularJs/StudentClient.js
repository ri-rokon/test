﻿var StudentApp = angular.module('StudentApp', [])



StudentApp.controller('StudentController', function ($scope) {



    $scope.message = "Application name";



})